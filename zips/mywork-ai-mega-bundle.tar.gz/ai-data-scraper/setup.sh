#!/bin/bash

# AI Data Scraper & Analyzer Setup Script
# This script sets up the development environment

set -e  # Exit on any error

echo "🕷️ Setting up AI Data Scraper & Analyzer..."

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if Python 3.11+ is available
print_status "Checking Python version..."
if command -v python3 &> /dev/null; then
    PYTHON_VERSION=$(python3 --version 2>&1 | grep -oE '[0-9]+\.[0-9]+')
    PYTHON_MAJOR=$(echo $PYTHON_VERSION | cut -d. -f1)
    PYTHON_MINOR=$(echo $PYTHON_VERSION | cut -d. -f2)
    
    if [ "$PYTHON_MAJOR" -lt 3 ] || ([ "$PYTHON_MAJOR" -eq 3 ] && [ "$PYTHON_MINOR" -lt 11 ]); then
        print_error "Python 3.11+ required, found $PYTHON_VERSION"
        exit 1
    else
        print_status "Python $PYTHON_VERSION found ✓"
    fi
else
    print_error "Python 3 not found. Please install Python 3.11+"
    exit 1
fi

# Check if pip is available
if ! command -v pip3 &> /dev/null; then
    print_error "pip3 not found. Please install pip"
    exit 1
fi

# Create virtual environment if it doesn't exist
if [ ! -d "venv" ]; then
    print_status "Creating virtual environment..."
    python3 -m venv venv
    print_status "Virtual environment created ✓"
else
    print_status "Virtual environment already exists ✓"
fi

# Activate virtual environment
print_status "Activating virtual environment..."
source venv/bin/activate

# Upgrade pip
print_status "Upgrading pip..."
pip install --upgrade pip

# Install requirements
print_status "Installing Python dependencies..."
if [ -f "requirements.txt" ]; then
    pip install -r requirements.txt
    print_status "Dependencies installed ✓"
else
    print_error "requirements.txt not found!"
    exit 1
fi

# Create .env file if it doesn't exist
if [ ! -f ".env" ]; then
    print_status "Creating .env file from template..."
    cp .env.example .env
    print_warning "Please edit .env file with your API keys before running the service"
else
    print_status ".env file already exists ✓"
fi

# Create necessary directories
print_status "Creating application directories..."
mkdir -p data
mkdir -p exports  
mkdir -p logs
print_status "Directories created ✓"

# Check for Chrome (for Selenium support)
if command -v google-chrome &> /dev/null || command -v chromium-browser &> /dev/null; then
    print_status "Chrome/Chromium found ✓"
    print_status "Selenium support available for dynamic content scraping"
else
    print_warning "Chrome/Chromium not found. Install for dynamic content scraping support"
    print_warning "Ubuntu/Debian: sudo apt-get install google-chrome-stable"
    print_warning "Or install via Docker for containerized deployment"
fi

# Check if Docker is available (optional)
if command -v docker &> /dev/null; then
    print_status "Docker found ✓"
    print_status "You can run 'docker build -t ai-data-scraper .' to build Docker image"
    print_status "Docker image includes Chrome and ChromeDriver automatically"
else
    print_warning "Docker not found. Install Docker for containerized deployment"
fi

# Check API keys in .env file
if [ -f ".env" ]; then
    if grep -q "your_openrouter_api_key_here" .env || grep -q "your_openai_api_key_here" .env; then
        print_warning "API keys not configured yet. Edit .env file with your API keys."
    else
        print_status "API keys appear to be configured ✓"
    fi
fi

# Test imports
print_status "Testing Python imports..."
python3 -c "
import fastapi
import uvicorn
import aiohttp
import pydantic
import requests
from bs4 import BeautifulSoup
from dotenv import load_dotenv
print('All core imports successful ✓')
" 2>/dev/null && print_status "Core import test passed ✓" || {
    print_error "Core import test failed. Some dependencies may be missing."
    exit 1
}

# Test Selenium import (optional)
python3 -c "
from selenium import webdriver
print('Selenium import successful ✓')
" 2>/dev/null && print_status "Selenium import test passed ✓" || {
    print_warning "Selenium import test failed. Dynamic content scraping may not work."
}

# Create sample configuration files
print_status "Creating sample configuration files..."

# Create sample scraping config
cat > sample_scraping_config.json << EOL
{
  "default_scraping": {
    "wait_time": 1.0,
    "max_pages": 10,
    "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    "timeout": 30
  },
  "extraction_selectors": {
    "ecommerce": {
      "title": "h1, .product-title",
      "price": ".price, .cost, [data-price]",
      "description": ".description, .product-desc",
      "rating": ".rating, .stars",
      "reviews": ".review-count, .reviews"
    },
    "blog": {
      "title": "h1, .entry-title",
      "content": ".content, .entry-content, article",
      "author": ".author, .byline",
      "date": ".date, .published, time"
    },
    "contact": {
      "email": "[href*='mailto:'], .email",
      "phone": ".phone, .tel, [href*='tel:']",
      "address": ".address, .location"
    }
  },
  "analysis_templates": {
    "competitive_analysis": "Analyze competitor data focusing on pricing, features, and positioning",
    "content_analysis": "Summarize key themes, topics, and insights from content",
    "sentiment_analysis": "Determine overall sentiment and emotional indicators",
    "trend_analysis": "Identify patterns, trends, and anomalies in the data"
  }
}
EOL

print_status "Sample configuration created ✓"

# Create sample Python usage script
cat > sample_usage.py << EOL
#!/usr/bin/env python3
"""
Sample usage of AI Data Scraper & Analyzer
"""

import requests
import time
import json

API_BASE = "http://localhost:8002"

def scrape_and_analyze_example():
    # Start scraping job
    scrape_request = {
        "urls": ["https://httpbin.org/html"],
        "scrape_type": "content",
        "wait_time": 1.0
    }
    
    print("Starting scraping job...")
    response = requests.post(f"{API_BASE}/scrape", json=scrape_request)
    job_data = response.json()
    job_id = job_data["job_id"]
    
    print(f"Job ID: {job_id}")
    
    # Monitor progress
    while True:
        status_response = requests.get(f"{API_BASE}/scrape/{job_id}")
        status = status_response.json()
        
        print(f"Status: {status['status']}")
        if status["status"] == "completed":
            break
        elif status["status"] == "failed":
            print(f"Job failed: {status.get('error')}")
            return
        
        time.sleep(2)
    
    # Get results
    results_response = requests.get(f"{API_BASE}/scrape/{job_id}/results")
    results = results_response.json()
    
    print(f"Scraped {len(results['results'])} pages")
    
    # Analyze the data
    analysis_request = {
        "data": json.dumps(results["results"]),
        "analysis_type": "summary"
    }
    
    print("Analyzing data...")
    analysis_response = requests.post(f"{API_BASE}/analyze", json=analysis_request)
    analysis = analysis_response.json()
    
    print(f"Analysis completed with confidence: {analysis['confidence_score']:.2f}")
    print(f"Results: {analysis['results']}")

if __name__ == "__main__":
    scrape_and_analyze_example()
EOL

chmod +x sample_usage.py
print_status "Sample usage script created ✓"

print_status "Setup completed successfully! 🎉"
echo
echo -e "${BLUE}Next steps:${NC}"
echo "1. Edit .env file with your API keys"
echo "2. Run the service: python main.py"
echo "3. Visit http://localhost:8002/docs for API documentation"
echo "4. Test health endpoint: curl http://localhost:8002/health"
echo "5. Try sample usage: python sample_usage.py"
echo
echo -e "${YELLOW}API Keys needed:${NC}"
echo "- OpenRouter API key: https://openrouter.ai/"
echo "- OR OpenAI API key: https://platform.openai.com/"
echo
echo -e "${GREEN}Service will run on: http://localhost:8002${NC}"
echo
echo -e "${BLUE}Example API calls:${NC}"
echo "# Start scraping job"
echo "curl -X POST 'http://localhost:8002/scrape' \\"
echo "  -H 'Content-Type: application/json' \\"
echo "  -d '{\"urls\":[\"https://httpbin.org/html\"],\"scrape_type\":\"content\"}'"
echo
echo "# Check job status (replace JOB_ID)"
echo "curl 'http://localhost:8002/scrape/JOB_ID'"
echo
echo "# Analyze data"
echo "curl -X POST 'http://localhost:8002/analyze' \\"
echo "  -H 'Content-Type: application/json' \\"
echo "  -d '{\"data\":\"Your data here\",\"analysis_type\":\"summary\"}'"
echo
echo -e "${YELLOW}For Selenium support:${NC}"
echo "- Install Chrome: sudo apt-get install google-chrome-stable"
echo "- Or use Docker (Chrome included automatically)"
echo
echo -e "${BLUE}Docker quick start:${NC}"
echo "docker build -t ai-data-scraper ."
echo "docker run -p 8002:8002 --env-file .env ai-data-scraper"