#!/usr/bin/env python3
"""
AI Data Scraper & Analyzer - FastAPI Service
Scrape websites and analyze data using AI
"""

import os
import uuid
import asyncio
import aiohttp
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any, Union
import json
import csv
import io
import zipfile
from urllib.parse import urljoin, urlparse

from fastapi import FastAPI, HTTPException, BackgroundTasks, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, HttpUrl, validator
import uvicorn
from bs4 import BeautifulSoup
import requests

# Load environment variables
from dotenv import load_dotenv
load_dotenv()

app = FastAPI(
    title="AI Data Scraper & Analyzer",
    description="Scrape websites and analyze data using AI",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configuration
OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY", "")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
DEFAULT_MODEL = "anthropic/claude-3.5-sonnet"

# In-memory storage (use database in production)
scraping_jobs = {}
analysis_results = {}

class ScrapeRequest(BaseModel):
    urls: List[HttpUrl]
    scrape_type: str = "content"  # content, links, images, forms, tables
    max_pages: int = 10
    include_subpages: bool = False
    follow_links: bool = False
    extract_data: Optional[Dict[str, str]] = None  # CSS selectors for specific data
    wait_time: float = 1.0  # seconds between requests
    user_agent: Optional[str] = None

class AnalysisRequest(BaseModel):
    data: Union[str, List[Dict[str, Any]], Dict[str, Any]]
    analysis_type: str = "summary"  # summary, sentiment, classification, extraction, insights
    context: Optional[str] = None
    extract_fields: Optional[List[str]] = None
    custom_prompt: Optional[str] = None

class ScrapeJobResponse(BaseModel):
    job_id: str
    status: str
    created_at: str
    urls: List[str]
    progress: Dict[str, Any]
    estimated_completion: Optional[str]

class AnalysisResponse(BaseModel):
    analysis_id: str
    analysis_type: str
    results: Dict[str, Any]
    confidence_score: Optional[float]
    created_at: str
    processing_time: float

class ScrapedData(BaseModel):
    url: str
    title: Optional[str]
    content: str
    links: List[str] = []
    images: List[str] = []
    metadata: Dict[str, Any] = {}
    scraped_at: str

def generate_job_id() -> str:
    """Generate unique job ID"""
    return str(uuid.uuid4())[:8].upper()

def get_user_agent() -> str:
    """Get default user agent"""
    return "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"

async def call_ai_api(prompt: str, model: str = DEFAULT_MODEL) -> str:
    """Call OpenRouter or OpenAI API"""
    headers = {
        "Authorization": f"Bearer {OPENROUTER_API_KEY}",
        "Content-Type": "application/json",
        "HTTP-Referer": "https://ai-data-scraper.local",
        "X-Title": "AI Data Scraper & Analyzer"
    }
    
    payload = {
        "model": model,
        "messages": [{"role": "user", "content": prompt}],
        "max_tokens": 4000,
        "temperature": 0.7
    }
    
    async with aiohttp.ClientSession() as session:
        try:
            async with session.post("https://openrouter.ai/api/v1/chat/completions", 
                                   headers=headers, json=payload) as response:
                if response.status == 200:
                    data = await response.json()
                    return data["choices"][0]["message"]["content"]
                else:
                    # Fallback to OpenAI if available
                    if OPENAI_API_KEY:
                        return await call_openai_api(prompt)
                    else:
                        raise HTTPException(status_code=500, detail=f"API call failed: {response.status}")
        except Exception as e:
            if OPENAI_API_KEY:
                return await call_openai_api(prompt)
            raise HTTPException(status_code=500, detail=f"AI API error: {str(e)}")

async def call_openai_api(prompt: str) -> str:
    """Fallback to OpenAI API"""
    headers = {
        "Authorization": f"Bearer {OPENAI_API_KEY}",
        "Content-Type": "application/json"
    }
    
    payload = {
        "model": "gpt-4",
        "messages": [{"role": "user", "content": prompt}],
        "max_tokens": 4000,
        "temperature": 0.7
    }
    
    async with aiohttp.ClientSession() as session:
        async with session.post("https://api.openai.com/v1/chat/completions", 
                               headers=headers, json=payload) as response:
            if response.status == 200:
                data = await response.json()
                return data["choices"][0]["message"]["content"]
            else:
                raise HTTPException(status_code=500, detail=f"OpenAI API error: {response.status}")

def scrape_url(url: str, scrape_type: str = "content", user_agent: Optional[str] = None) -> ScrapedData:
    """Scrape a single URL"""
    headers = {
        "User-Agent": user_agent or get_user_agent(),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate",
        "Connection": "keep-alive",
    }
    
    try:
        response = requests.get(str(url), headers=headers, timeout=30)
        response.raise_for_status()
        
        soup = BeautifulSoup(response.content, 'html.parser')
        
        # Extract title
        title = soup.title.string.strip() if soup.title else None
        
        # Extract content based on type
        content = ""
        links = []
        images = []
        metadata = {}
        
        if scrape_type == "content":
            # Remove script and style elements
            for script in soup(["script", "style"]):
                script.decompose()
            content = soup.get_text()
            # Clean up whitespace
            content = '\n'.join(line.strip() for line in content.splitlines() if line.strip())
        
        elif scrape_type == "links":
            links = [urljoin(str(url), a.get('href')) for a in soup.find_all('a', href=True)]
            content = f"Found {len(links)} links"
        
        elif scrape_type == "images":
            images = [urljoin(str(url), img.get('src')) for img in soup.find_all('img', src=True)]
            content = f"Found {len(images)} images"
        
        elif scrape_type == "tables":
            tables = soup.find_all('table')
            table_data = []
            for i, table in enumerate(tables):
                rows = []
                for tr in table.find_all('tr'):
                    row = [td.get_text().strip() for td in tr.find_all(['td', 'th'])]
                    if row:
                        rows.append(row)
                if rows:
                    table_data.append({"table_index": i, "rows": rows})
            content = json.dumps(table_data, indent=2)
        
        elif scrape_type == "forms":
            forms = soup.find_all('form')
            form_data = []
            for i, form in enumerate(forms):
                inputs = []
                for input_tag in form.find_all(['input', 'select', 'textarea']):
                    inputs.append({
                        "type": input_tag.get('type', input_tag.name),
                        "name": input_tag.get('name'),
                        "id": input_tag.get('id'),
                        "required": input_tag.get('required') is not None
                    })
                form_data.append({
                    "action": form.get('action'),
                    "method": form.get('method', 'GET'),
                    "inputs": inputs
                })
            content = json.dumps(form_data, indent=2)
        
        # Extract metadata
        metadata = {
            "status_code": response.status_code,
            "content_type": response.headers.get('content-type', ''),
            "content_length": len(response.content),
            "language": soup.html.get('lang') if soup.html else None,
            "meta_description": None,
            "meta_keywords": None
        }
        
        # Extract meta tags
        meta_description = soup.find('meta', attrs={'name': 'description'})
        if meta_description:
            metadata["meta_description"] = meta_description.get('content')
        
        meta_keywords = soup.find('meta', attrs={'name': 'keywords'})
        if meta_keywords:
            metadata["meta_keywords"] = meta_keywords.get('content')
        
        return ScrapedData(
            url=str(url),
            title=title,
            content=content,
            links=links,
            images=images,
            metadata=metadata,
            scraped_at=datetime.utcnow().isoformat()
        )
    
    except Exception as e:
        return ScrapedData(
            url=str(url),
            title=None,
            content=f"Error scraping URL: {str(e)}",
            links=[],
            images=[],
            metadata={"error": str(e)},
            scraped_at=datetime.utcnow().isoformat()
        )

async def perform_scraping_job(job_id: str, request: ScrapeRequest):
    """Perform scraping job in background"""
    job = scraping_jobs[job_id]
    
    try:
        job["status"] = "running"
        job["started_at"] = datetime.utcnow().isoformat()
        
        scraped_data = []
        total_urls = len(request.urls)
        
        for i, url in enumerate(request.urls):
            # Update progress
            job["progress"] = {
                "completed": i,
                "total": total_urls,
                "current_url": str(url),
                "percentage": (i / total_urls) * 100
            }
            
            # Scrape URL
            data = scrape_url(url, request.scrape_type, request.user_agent)
            scraped_data.append(data)
            
            # Wait between requests
            if i < total_urls - 1:
                await asyncio.sleep(request.wait_time)
        
        # Store results
        job["status"] = "completed"
        job["results"] = [data.dict() for data in scraped_data]
        job["completed_at"] = datetime.utcnow().isoformat()
        job["progress"]["percentage"] = 100
        
    except Exception as e:
        job["status"] = "failed"
        job["error"] = str(e)
        job["failed_at"] = datetime.utcnow().isoformat()

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "AI Data Scraper & Analyzer",
        "timestamp": datetime.utcnow().isoformat(),
        "version": "1.0.0",
        "active_jobs": len([j for j in scraping_jobs.values() if j["status"] == "running"]),
        "completed_jobs": len([j for j in scraping_jobs.values() if j["status"] == "completed"])
    }

@app.post("/scrape", response_model=ScrapeJobResponse)
async def start_scraping_job(request: ScrapeRequest, background_tasks: BackgroundTasks):
    """Start a web scraping job"""
    
    # Validate URLs
    if not request.urls:
        raise HTTPException(status_code=400, detail="At least one URL is required")
    
    if len(request.urls) > request.max_pages:
        raise HTTPException(status_code=400, detail=f"Too many URLs. Maximum allowed: {request.max_pages}")
    
    # Create job
    job_id = generate_job_id()
    job = {
        "job_id": job_id,
        "status": "queued",
        "created_at": datetime.utcnow().isoformat(),
        "urls": [str(url) for url in request.urls],
        "scrape_type": request.scrape_type,
        "progress": {"completed": 0, "total": len(request.urls), "percentage": 0},
        "results": []
    }
    
    scraping_jobs[job_id] = job
    
    # Start scraping in background
    background_tasks.add_task(perform_scraping_job, job_id, request)
    
    # Estimate completion time
    estimated_time = len(request.urls) * (request.wait_time + 2)  # 2 seconds per URL + wait time
    estimated_completion = (datetime.utcnow() + timedelta(seconds=estimated_time)).isoformat()
    
    return ScrapeJobResponse(
        job_id=job_id,
        status="queued",
        created_at=job["created_at"],
        urls=job["urls"],
        progress=job["progress"],
        estimated_completion=estimated_completion
    )

@app.get("/scrape/{job_id}")
async def get_scraping_job_status(job_id: str):
    """Get status of a scraping job"""
    
    if job_id not in scraping_jobs:
        raise HTTPException(status_code=404, detail="Job not found")
    
    job = scraping_jobs[job_id]
    return {
        "job_id": job_id,
        "status": job["status"],
        "created_at": job["created_at"],
        "progress": job["progress"],
        "results_count": len(job.get("results", [])),
        "error": job.get("error"),
        "started_at": job.get("started_at"),
        "completed_at": job.get("completed_at"),
        "failed_at": job.get("failed_at")
    }

@app.get("/scrape/{job_id}/results")
async def get_scraping_results(job_id: str, format: str = Query("json", description="Response format: json, csv")):
    """Get results of a scraping job"""
    
    if job_id not in scraping_jobs:
        raise HTTPException(status_code=404, detail="Job not found")
    
    job = scraping_jobs[job_id]
    
    if job["status"] != "completed":
        raise HTTPException(status_code=400, detail=f"Job status is {job['status']}, not completed")
    
    results = job["results"]
    
    if format == "csv":
        # Convert to CSV
        output = io.StringIO()
        if results:
            writer = csv.DictWriter(output, fieldnames=results[0].keys())
            writer.writeheader()
            for result in results:
                # Flatten complex objects for CSV
                flat_result = {}
                for k, v in result.items():
                    if isinstance(v, (dict, list)):
                        flat_result[k] = json.dumps(v)
                    else:
                        flat_result[k] = v
                writer.writerow(flat_result)
        
        return StreamingResponse(
            io.BytesIO(output.getvalue().encode()),
            media_type="text/csv",
            headers={"Content-Disposition": f"attachment; filename=scraping_results_{job_id}.csv"}
        )
    
    return {"job_id": job_id, "results": results, "count": len(results)}

@app.post("/analyze", response_model=AnalysisResponse)
async def analyze_data(request: AnalysisRequest):
    """Analyze scraped data using AI"""
    
    start_time = datetime.utcnow()
    analysis_id = generate_job_id()
    
    # Prepare data for analysis
    if isinstance(request.data, str):
        data_text = request.data
    elif isinstance(request.data, list):
        data_text = json.dumps(request.data, indent=2)
    else:
        data_text = json.dumps(request.data, indent=2)
    
    # Truncate if too long
    if len(data_text) > 50000:
        data_text = data_text[:50000] + "... [truncated]"
    
    # Build analysis prompt
    base_prompts = {
        "summary": "Analyze the following data and provide a comprehensive summary highlighting key insights, patterns, and important findings:",
        "sentiment": "Analyze the sentiment of the following data. Provide sentiment scores and key emotional indicators:",
        "classification": "Classify and categorize the following data into meaningful groups. Identify patterns and common themes:",
        "extraction": "Extract structured information from the following data. Identify entities, relationships, and key data points:",
        "insights": "Provide business insights and actionable recommendations based on the following data:",
        "trends": "Identify trends, patterns, and anomalies in the following data:",
        "competitive": "Analyze competitive intelligence and market insights from the following data:"
    }
    
    if request.custom_prompt:
        prompt = f"{request.custom_prompt}\n\nData to analyze:\n{data_text}"
    else:
        base_prompt = base_prompts.get(request.analysis_type, base_prompts["summary"])
        prompt = f"{base_prompt}\n\n"
        
        if request.context:
            prompt += f"Context: {request.context}\n\n"
        
        if request.extract_fields:
            prompt += f"Focus on extracting these specific fields: {', '.join(request.extract_fields)}\n\n"
        
        prompt += f"Data to analyze:\n{data_text}\n\n"
        prompt += "Please provide your analysis in a structured format with clear sections and actionable insights."
    
    try:
        # Call AI API
        ai_response = await call_ai_api(prompt)
        
        # Try to parse as JSON if possible
        try:
            results = json.loads(ai_response)
        except json.JSONDecodeError:
            results = {"analysis": ai_response, "format": "text"}
        
        # Calculate confidence score based on response length and structure
        confidence_score = min(0.95, 0.5 + (len(ai_response) / 5000) * 0.45)
        
        processing_time = (datetime.utcnow() - start_time).total_seconds()
        
        analysis_result = AnalysisResponse(
            analysis_id=analysis_id,
            analysis_type=request.analysis_type,
            results=results,
            confidence_score=confidence_score,
            created_at=start_time.isoformat(),
            processing_time=processing_time
        )
        
        # Store result
        analysis_results[analysis_id] = analysis_result.dict()
        
        return analysis_result
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Analysis failed: {str(e)}")

@app.get("/exports/{job_id}")
async def export_job_data(job_id: str, format: str = Query("zip", description="Export format: zip, json, csv")):
    """Export job data in various formats"""
    
    if job_id not in scraping_jobs:
        raise HTTPException(status_code=404, detail="Job not found")
    
    job = scraping_jobs[job_id]
    
    if job["status"] != "completed":
        raise HTTPException(status_code=400, detail=f"Job status is {job['status']}, not completed")
    
    results = job["results"]
    
    if format == "json":
        return {
            "job_id": job_id,
            "job_info": {k: v for k, v in job.items() if k != "results"},
            "results": results
        }
    
    elif format == "csv":
        output = io.StringIO()
        if results:
            writer = csv.DictWriter(output, fieldnames=results[0].keys())
            writer.writeheader()
            for result in results:
                # Flatten complex objects
                flat_result = {}
                for k, v in result.items():
                    if isinstance(v, (dict, list)):
                        flat_result[k] = json.dumps(v)
                    else:
                        flat_result[k] = v
                writer.writerow(flat_result)
        
        return StreamingResponse(
            io.BytesIO(output.getvalue().encode()),
            media_type="text/csv",
            headers={"Content-Disposition": f"attachment; filename=export_{job_id}.csv"}
        )
    
    elif format == "zip":
        # Create ZIP file with multiple formats
        zip_buffer = io.BytesIO()
        
        with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
            # Add job info as JSON
            job_info = {k: v for k, v in job.items() if k != "results"}
            zip_file.writestr(f"job_info_{job_id}.json", json.dumps(job_info, indent=2))
            
            # Add results as JSON
            zip_file.writestr(f"results_{job_id}.json", json.dumps(results, indent=2))
            
            # Add results as CSV
            if results:
                csv_output = io.StringIO()
                writer = csv.DictWriter(csv_output, fieldnames=results[0].keys())
                writer.writeheader()
                for result in results:
                    flat_result = {}
                    for k, v in result.items():
                        if isinstance(v, (dict, list)):
                            flat_result[k] = json.dumps(v)
                        else:
                            flat_result[k] = v
                    writer.writerow(flat_result)
                zip_file.writestr(f"results_{job_id}.csv", csv_output.getvalue())
            
            # Add individual scraped content files
            for i, result in enumerate(results):
                if result.get("content"):
                    filename = f"content_{i}_{urlparse(result['url']).netloc}.txt"
                    zip_file.writestr(filename, result["content"])
        
        zip_buffer.seek(0)
        
        return StreamingResponse(
            io.BytesIO(zip_buffer.read()),
            media_type="application/zip",
            headers={"Content-Disposition": f"attachment; filename=export_{job_id}.zip"}
        )
    
    else:
        raise HTTPException(status_code=400, detail="Invalid format. Use json, csv, or zip")

@app.get("/stats")
async def get_service_stats():
    """Get service statistics"""
    
    total_jobs = len(scraping_jobs)
    completed_jobs = len([j for j in scraping_jobs.values() if j["status"] == "completed"])
    running_jobs = len([j for j in scraping_jobs.values() if j["status"] == "running"])
    failed_jobs = len([j for j in scraping_jobs.values() if j["status"] == "failed"])
    
    total_analyses = len(analysis_results)
    
    # Calculate total pages scraped
    total_pages = sum(len(job.get("results", [])) for job in scraping_jobs.values())
    
    return {
        "service": "AI Data Scraper & Analyzer",
        "jobs": {
            "total": total_jobs,
            "completed": completed_jobs,
            "running": running_jobs,
            "failed": failed_jobs,
            "queued": total_jobs - completed_jobs - running_jobs - failed_jobs
        },
        "scraping": {
            "total_pages_scraped": total_pages,
            "supported_formats": ["content", "links", "images", "forms", "tables"]
        },
        "analysis": {
            "total_analyses": total_analyses,
            "supported_types": ["summary", "sentiment", "classification", "extraction", "insights", "trends", "competitive"]
        },
        "export_formats": ["json", "csv", "zip"],
        "ai_models": ["Claude 3.5 Sonnet", "GPT-4"]
    }

@app.delete("/scrape/{job_id}")
async def delete_job(job_id: str):
    """Delete a scraping job and its results"""
    
    if job_id not in scraping_jobs:
        raise HTTPException(status_code=404, detail="Job not found")
    
    job = scraping_jobs.pop(job_id)
    
    return {
        "message": "Job deleted successfully",
        "job_id": job_id,
        "deleted_at": datetime.utcnow().isoformat()
    }

if __name__ == "__main__":
    port = int(os.getenv("PORT", 8002))
    uvicorn.run(app, host="0.0.0.0", port=port)