# AI Data Scraper & Analyzer
> Smart web scraper with AI-powered data analysis and competitive intelligence capabilities

## 🎯 What This Does
Extracts data from websites and analyzes it using AI for business insights, competitive intelligence, and market research. Features intelligent content extraction, sentiment analysis, trend detection, and multi-format export. Perfect for data analysts, marketers, and research teams.

## ✨ Features
- 🕷️ **Smart Web Scraping** - Extract text, links, images, forms, and tables from any website
- 🤖 **AI-Powered Analysis** - Sentiment analysis, classification, and insight generation
- 🔄 **Background Processing** - Async job handling with real-time progress tracking
- 📊 **Multiple Export Formats** - JSON, CSV, and ZIP downloads for easy analysis
- 🎯 **Custom Data Extraction** - CSS selectors and XPath for precise targeting
- 🏆 **Competitive Intelligence** - Analyze competitor strategies and market positioning
- 🌐 **Selenium Integration** - Handle dynamic content and JavaScript-heavy sites
- ⚡ **Bulk Processing** - Scrape multiple URLs simultaneously with queue management
- 🛡️ **Respectful Scraping** - Built-in rate limiting and robots.txt compliance
- 📈 **Trend Detection** - Identify patterns and anomalies in scraped data

## 🚀 Quick Start
1. Clone the repo: `git clone <repo-url>`
2. Copy `.env.example` to `.env`
3. Fill in API keys:
   - **OpenRouter API Key**: Get from [OpenRouter](https://openrouter.ai/keys) for multi-model AI
   - **OpenAI API Key**: Alternative from [OpenAI Platform](https://platform.openai.com/api-keys)
4. Run `pip install -r requirements.txt` to install dependencies
5. Test with `python main.py` and visit `http://localhost:8000/docs` for API documentation

## 📡 API Endpoints

| Method | Endpoint | Description | Example |
|--------|----------|-------------|---------|
| POST | `/scrape` | Start new scraping job | `curl -X POST -H "Content-Type: application/json" -d '{"urls":["https://example.com"],"scrape_type":"content","max_pages":10}' http://localhost:8000/scrape` |
| GET | `/scrape/{job_id}` | Get job status and progress | `curl http://localhost:8000/scrape/job_abc123` |
| GET | `/scrape/{job_id}/results` | Retrieve scraping results | `curl http://localhost:8000/scrape/job_abc123/results?format=json` |
| POST | `/analyze` | Analyze scraped data with AI | `curl -X POST -H "Content-Type: application/json" -d '{"data":"Your scraped content...","analysis_type":"sentiment","target_keywords":["product","review"]}' http://localhost:8000/analyze` |
| GET | `/exports/{job_id}` | Export data in various formats | `curl http://localhost:8000/exports/job_abc123?format=csv&include_analysis=true` |
| DELETE | `/scrape/{job_id}` | Delete job and cleanup data | `curl -X DELETE http://localhost:8000/scrape/job_abc123` |
| GET | `/jobs` | List all scraping jobs | `curl http://localhost:8000/jobs?status=completed&limit=20` |
| GET | `/health` | Service health and status | `curl http://localhost:8000/health` |
| GET | `/stats` | Usage statistics and metrics | `curl http://localhost:8000/stats` |

## 💡 Use Cases
- **E-commerce Price Monitoring** - Track competitor pricing and product availability across multiple stores
- **Content Marketing Research** - Analyze competitor blog content, topics, and engagement strategies
- **Lead Generation** - Extract contact information and business details from industry directories
- **SEO Competitive Analysis** - Monitor competitor content strategies, keywords, and search rankings
- **Perfect for** - Marketing teams, data analysts, and research professionals needing scalable web data collection

## 🔧 Configuration

| Variable | Description | Where to Get | Default |
|----------|-------------|--------------|---------|
| `OPENROUTER_API_KEY` | Multi-model AI access (recommended) | [OpenRouter Keys](https://openrouter.ai/keys) | - |
| `OPENAI_API_KEY` | Direct OpenAI access (alternative) | [OpenAI Platform](https://platform.openai.com/api-keys) | - |
| `DEFAULT_AI_MODEL` | AI model for analysis | `anthropic/claude-3-sonnet`, `openai/gpt-4` | `anthropic/claude-3-sonnet` |
| `MAX_PAGES_PER_JOB` | Scraping limit per job | Number of pages | 1000 |
| `MAX_CONCURRENT_JOBS` | Parallel processing limit | Number of simultaneous jobs | 5 |
| `REQUEST_DELAY` | Respectful scraping delay | Seconds between requests | 1.0 |
| `REQUEST_TIMEOUT` | Page load timeout | Seconds | 30 |
| `USER_AGENT` | Browser identification | Custom user agent string | Default browser agent |
| `ENABLE_SELENIUM` | Dynamic content support | true/false | false |
| `CHROME_DRIVER_PATH` | Selenium ChromeDriver | Path to chromedriver binary | Auto-detect |
| `PROXY_URL` | Proxy configuration (optional) | HTTP/SOCKS proxy URL | - |
| `DATA_RETENTION_DAYS` | Storage cleanup | Days to keep job data | 7 |
| `MAX_CONTENT_SIZE` | Content size limit | Bytes per page | 10485760 (10MB) |
| `DATABASE_URL` | Job storage | SQLite or PostgreSQL | `sqlite:///scraper.db` |
| `REDIS_URL` | Job queue (optional) | Redis connection string | - |

## 🐳 Docker Deployment
```yaml
version: '3.8'
services:
  ai-data-scraper:
    build: .
    ports:
      - "8000:8000"
    environment:
      - OPENROUTER_API_KEY=${OPENROUTER_API_KEY}
      - DEFAULT_AI_MODEL=anthropic/claude-3-sonnet
      - MAX_PAGES_PER_JOB=1000
      - REQUEST_DELAY=1.0
      - ENABLE_SELENIUM=true
      - DATABASE_URL=postgresql://postgres:password@db:5432/scraper
    depends_on:
      - db
      - redis
    volumes:
      - ./data:/app/data
      - ./exports:/app/exports
    restart: unless-stopped

  db:
    image: postgres:15
    environment:
      - POSTGRES_DB=scraper
      - POSTGRES_PASSWORD=password
    volumes:
      - postgres_data:/var/lib/postgresql/data

  redis:
    image: redis:7-alpine
    volumes:
      - redis_data:/data

  chrome:
    image: selenium/standalone-chrome
    ports:
      - "4444:4444"
    shm_size: 2gb

volumes:
  postgres_data:
  redis_data:
```

Commands:
```bash
docker-compose up -d
curl http://localhost:8000/health
```

## 📊 Architecture
```
Scrape Request → URL Queue → Rate Limiter → Web Scraper
      ↓                                          ↓
Job Management ← Progress Tracking ← Content Extraction
      ↓                                          ↓
AI Analysis Engine ← Data Processing ← Content Storage
      ↓                                          ↓
Export Generator ← Results Formatting ← Insights Generation
```

Core Components:
- **Web Scraper**: BeautifulSoup + Selenium for comprehensive data extraction
- **AI Analyzer**: Multi-model AI for sentiment, classification, and insights
- **Job Scheduler**: Background processing with progress tracking
- **Export Engine**: Multiple format support with customizable outputs
- **Rate Limiter**: Respectful scraping with configurable delays

## 🆘 Troubleshooting
**Scraping jobs failing:**
- Check target website accessibility and robots.txt compliance
- Verify request timeout settings for slow-loading pages
- Monitor rate limiting and respect website policies
- Check for anti-bot measures like CAPTCHAs or IP blocking

**Selenium/ChromeDriver issues:**
- Ensure ChromeDriver version matches installed Chrome
- Check Docker container has sufficient memory (2GB+ recommended)
- Verify headless browser configuration
- Monitor Selenium grid connectivity in Docker setup

**AI analysis errors:**
- Check API key has sufficient credits and quota
- Verify model availability on OpenRouter/OpenAI
- Monitor content size limits for AI processing
- Try alternative models if primary model fails

**Memory usage problems:**
- Limit concurrent jobs with MAX_CONCURRENT_JOBS
- Reduce MAX_PAGES_PER_JOB for large scraping tasks
- Enable data cleanup with DATA_RETENTION_DAYS
- Monitor content size limits per page

**Export generation failures:**
- Check disk space in exports directory
- Verify write permissions for export files
- Monitor large dataset export timeouts
- Try smaller data chunks for massive exports

**Database connection issues:**
- Verify database credentials and connectivity
- Check database schema migrations are current
- Monitor connection pool limits and timeouts
- Ensure proper indexing for job queries

**Rate limiting problems:**
- Increase REQUEST_DELAY for strict websites
- Use rotating proxy pools for large-scale scraping
- Implement random delays between requests
- Monitor IP blocking and implement retry logic

**Content extraction issues:**
- Verify CSS selectors and XPath expressions
- Check for dynamic content loading requirements
- Enable Selenium for JavaScript-heavy sites
- Monitor page structure changes that break selectors

## 📝 License
Private — purchased via MyWork-AI Marketplace