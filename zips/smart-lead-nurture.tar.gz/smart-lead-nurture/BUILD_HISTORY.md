# 🎯 Smart Lead Nurture — Build History

> Building an automated lead nurturing workflow with n8n.

## Step 1: Why n8n (2 min)
This product is different — it's an **n8n workflow**, not a Python API. n8n is a visual automation tool (like Zapier but self-hosted). Perfect for email sequences and CRM automations.

## Step 2: Design the Workflow (10 min)
```
New Lead (Webhook) → Welcome Email (5 min delay)
       ↓
   Day 3: Case Study Email
       ↓
   Day 7: Special Offer Email
       ↓
   Lead Scoring (based on opens/clicks)
       ↓
   If score > 70: Notify Sales Team
```

## Step 3: Build in n8n (20 min)
1. **Webhook Trigger** — receives new lead data (name, email, source)
2. **Wait Node** — 5 minute delay for welcome email
3. **Send Email** — SMTP node sends personalized welcome
4. **Wait Node** — 3 day delay
5. **Send Email** — Case study with social proof
6. **Wait Node** — 4 more days
7. **IF Node** — Check if lead opened previous emails
8. **Send Email** — Special offer (only to engaged leads)
9. **HTTP Node** — Update CRM with lead score

## Step 4: Export the Workflow (2 min)
```bash
# n8n exports workflows as JSON
# The buyer imports it into their n8n instance
n8n import:workflow --input=src/workflow.json
```

## Step 5: Make It Configurable (5 min)
The workflow uses environment variables:
- SMTP settings (any email provider)
- Email templates (editable)
- Timing between emails (adjustable)
- Lead score thresholds (customizable)

## Total Build Time: ~39 minutes

## Why It Sells
- Lead nurturing is proven to increase conversions 20-50%
- Most businesses don't have time to build sequences
- Works with any email provider (not locked to Mailchimp)
- n8n is free and self-hosted
