# 📄 Invoice Generator API — Build History

> How to build a complete invoicing system in under an hour.

## Step 1: Why This Product (2 min)
Every freelancer and small business needs invoices. Most use expensive SaaS ($10-30/mo). A self-hosted API costs $0.

## Step 2: Design the Invoice Model (5 min)
```python
class Invoice:
    id: "INV-2026-0001"  # Auto-generated
    client_name, client_email
    items: [{description, quantity, unit_price}]
    subtotal, tax_rate, total
    status: draft → sent → paid → overdue
    due_date, notes
```

## Step 3: Build CRUD (15 min)
- `POST /invoices` — Create with line items, auto-calculate totals
- `GET /invoices` — List with filters (status, date range)
- `PUT /invoices/{id}` — Update status, add items
- `DELETE /invoices/{id}` — Remove draft invoices

## Step 4: PDF Generation (15 min)
```python
@app.get("/invoices/{id}/pdf")
async def get_pdf(invoice_id):
    # 1. Load invoice from SQLite
    # 2. Render Jinja2 HTML template (templates/invoice.html)
    # 3. Convert HTML → PDF with WeasyPrint
    # 4. Return as downloadable file
```

**Key insight:** Using an HTML template means the invoice design is fully customizable. Change colors, logo, layout — just edit the HTML.

## Step 5: HTML Preview (5 min)
```python
@app.get("/invoices/{id}/html")
# Same template, but returns rendered HTML
# Perfect for email embedding or browser preview
```

## Step 6: Auto-Numbering (5 min)
```python
# INV-{YEAR}-{SEQUENCE}
# INV-2026-0001, INV-2026-0002, etc.
# Resets each year, always sequential
```

## Total Build Time: ~47 minutes

## Why It Sells
- $19.99 one-time vs $10-30/month for cloud invoicing
- Self-hosted = your data stays yours
- Customizable template = matches your brand
- API = integrate into any app or workflow
