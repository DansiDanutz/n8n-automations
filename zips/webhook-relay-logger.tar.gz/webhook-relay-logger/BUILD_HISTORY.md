# 🔗 Webhook Relay & Logger — Build History

> Building a webhook debugging and routing tool.

## Step 1: The Problem (2 min)
Every developer struggles with webhooks: "Did Stripe send it? What was the payload? Why did my handler crash?" This tool captures, inspects, replays, and routes webhooks.

## Step 2: Dynamic Endpoints (10 min)
```python
@app.post("/endpoints")
# Creates a unique webhook URL: /webhook/ep_a1b2c3
# Any POST to that URL gets captured and logged
# Like RequestBin, but self-hosted and permanent
```

**Why dynamic?** Each integration gets its own endpoint. Stripe payments → ep_abc. GitHub pushes → ep_def. Clean separation.

## Step 3: Payload Capture (10 min)
```python
# When a webhook hits /webhook/{endpoint_id}:
# 1. Capture: headers, body, method, query params, IP
# 2. Store in SQLite with timestamp
# 3. Return 200 OK (so the sender doesn't retry)
# 4. Trigger relay rules (if configured)
```

## Step 4: Relay Rules (15 min)
```python
@app.post("/relays")
# "When endpoint ep_abc receives a webhook:
#   → Forward to https://myapp.com/api/payments
#   → But only if body.type == 'payment_intent.succeeded'"
# 
# Filters let you route specific events to specific handlers
```

## Step 5: Replay (5 min)
```python
@app.post("/webhooks/{id}/replay")
# Re-send a captured webhook to your handler
# Perfect for debugging: fix the bug, replay, verify
```

## Step 6: Visual Dashboard (10 min)
```python
@app.get("/dashboard")
# Real-time view of all incoming webhooks
# Click to inspect full payload
# Charts showing webhook volume over time
```

## Total Build Time: ~52 minutes

## Why It Sells
- ngrok/RequestBin are temporary. This is permanent.
- Relay rules = webhook routing (no custom code needed)
- Replay = debug without triggering real events
- $19.99 vs $10-25/month for similar SaaS tools
